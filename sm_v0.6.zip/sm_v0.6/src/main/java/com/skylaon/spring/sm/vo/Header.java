
package com.skylaon.spring.sm.vo;

public class Header {

    public String resultCode;
    public String resultMsg;

}
