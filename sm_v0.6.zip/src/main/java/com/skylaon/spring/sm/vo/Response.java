
package com.skylaon.spring.sm.vo;

public class Response {

    public Header header;
    public Body body;

}
