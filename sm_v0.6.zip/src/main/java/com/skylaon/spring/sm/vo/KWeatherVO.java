
package com.skylaon.spring.sm.vo;

public class KWeatherVO {

    public Response response;

}
