package com.skylaon.spring.sm.board;

public class ConfigBoard {
	static public int AMOUNT_PER_PAGE = 5;
	static public int PAGE_PER_BLOCK = 3;
}
