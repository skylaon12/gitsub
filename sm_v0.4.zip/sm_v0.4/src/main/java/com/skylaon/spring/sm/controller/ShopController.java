package com.skylaon.spring.sm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.skylaon.spring.sm.service.ProductService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/shop/*")
@AllArgsConstructor
@Controller
public class ShopController {
	private ProductService service;
	
	@RequestMapping("/category")
	public void category() {
		
	}
	
	@RequestMapping("/pdList")
	public void productList(int id, Model m) {
		log.info("컨트롤러진입");
		m.addAttribute("products", service.getProductList(id));
	}
	
	@RequestMapping("/productInfo")
	public void productInfo(int p_id, Model m) {
		log.info(p_id);
		m.addAttribute("product", service.getProductInfo(p_id));
	}
}
