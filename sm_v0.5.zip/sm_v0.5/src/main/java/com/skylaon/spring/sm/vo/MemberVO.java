package com.skylaon.spring.sm.vo;

import lombok.Data;

@Data
public class MemberVO {
	private String u_id;
	private String u_pw;
	private String u_name;
	private int u_age;
	private String u_gender;
}
