package com.skylaon.spring.sm.service;

import java.util.ArrayList;

import com.skylaon.jsp.BoardListProcessor;
import com.skylaon.spring.sm.vo.GuestVO;

public interface GuestService {
	public ArrayList<GuestVO> getList(int currentPage);	// 리스트
	public GuestVO read(long bno);	// read
	public void del(long bno); 		// delete
	public void write(GuestVO gvo);	// write
	public void modify(GuestVO gvo);// update
	
	public int getPostCount();
	
	public BoardListProcessor list(String currentPage);
}
